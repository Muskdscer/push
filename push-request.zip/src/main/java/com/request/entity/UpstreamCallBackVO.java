package com.request.entity;

import lombok.Data;

/**
 * Description:
 * Create DateTime: 2020-04-02 17:46
 *
 * 

 */
@Data
public class UpstreamCallBackVO {

    /**
     * 渠道订单号
     */
    private String orderNo;

    /**
     * 平台订单号
     */
    private String bizOrderNo;

}
