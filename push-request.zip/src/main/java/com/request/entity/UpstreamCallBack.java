package com.request.entity;

import lombok.Data;
import lombok.ToString;

/**
 * Description:
 * Create DateTime: 2020-04-02 18:45
 *
 * 

 */
@Data
@ToString
public class UpstreamCallBack {

    private String url;

    private Object data;

}
