package com.request.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * Description:
 * Create DateTime: 2020-04-01 13:24
 *
 * 

 */
@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class PhoneOrderWaitCheck {

    /**
     * 查询地址
     */
    private String querySite;

    /**
     * 平台订单号
     */
    private String platformOrderNo;

    /**
     * 商户订单号
     */
    private String shopOrderNo;

    /**
     * 网厅流水号
     */
    private String orderSn;

    /**
     * 订单状态
     */
    private Integer status;

    /**
     * 详细信息
     */
    private String message;

    /**
     * 凭证
     */
    private String certificate;

    /**
     * 分类名称
     */
    private String classifyName;

    /**
     * appId
     */
    private String appId;

    /**
     * appKey
     */
    private String appKey;

    /**
     * 充值类型 0: 快充  1: 慢充 (此参数为后期添加参数, 如果不传, 默认是快充)
     */
    private Integer rechargeType;

}
