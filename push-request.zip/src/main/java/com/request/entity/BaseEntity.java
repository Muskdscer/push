package com.request.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.request.common.constants.DateConstant;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import java.io.Serializable;
import java.util.Date;

/**
 * Description: 基类
 * Create DateTime: 2020-03-25 18:20
 *
 * 

 */
@Data
public class BaseEntity implements Serializable {

    protected Long id;

    protected Integer deleteFlag;

    @CreatedDate
    @JsonFormat(pattern = DateConstant.DATE_TIME_FORMAT_TWO, timezone = DateConstant.TIME_ZONE)
    protected Date createTime;

    @LastModifiedDate
    @JsonFormat(pattern = DateConstant.DATE_TIME_FORMAT_TWO, timezone = DateConstant.TIME_ZONE)
    protected Date updateTime;

}
