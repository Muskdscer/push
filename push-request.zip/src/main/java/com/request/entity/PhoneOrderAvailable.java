package com.request.entity;

import com.request.common.enums.OperatorChannelTypeEnum;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * <p>
 * 可用订单表
 * </p>
 *
 * 

 * @since 2020-03-27
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class PhoneOrderAvailable extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;


    /**
     * 上游用户id
     */
    private Long upstreamUserId;

    /**
     * 商户id
     */
    private Long shopUserId;

    /**
     * 上游订单号
     */
    private String upstreamOrderNo;

    /**
     * 平台订单号
     */
    private String platformOrderNo;

    /**
     * 商户订单号
     */
    private String shopOrderNo;

    /**
     * 网厅流水号
     */
    private String orderSn;

    /**
     * 手机号
     */
    private String phoneNum;

    /**
     * 手机运营商
     */
    private String phoneOperator;

    /**
     * 手机运营商通道类型  {@link OperatorChannelTypeEnum}
     */
    private String type;

    /**
     * 上游推送订单金额
     */
    private BigDecimal orderPrice;

    /**
     * 推送商户订单金额
     */
    private BigDecimal shopPrice;

    /**
     * 订单过期时间
     */
    private Integer orderExpireTime;

    /**
     * 订单过期状态0:未过期1:已过期
     */
    private Integer orderExpireStatus;

    /**
     * 推送状态0:未推送1:已推动
     */
    private Integer pushStatus;

    /**
     * 上游回调状态0:回调失败1回调成功
     */
    private Integer upstreamCallbackStatus;

    /**
     * 商户回调状态0:回调失败1回调成功
     */
    private Integer shopCallbackStatus;

    /**
     * 平台订单状态
     * 0:未使用
     * 1:已推送
     * 2:消费完成
     * 3:消费失败
     * 4:上游响应失败
     */
    private Integer platformOrderStatus;

    /**
     * 平台记账状态0:未记账1:已记账
     */
    private Integer platformBillStatus;

    /**
     * 商户记账状态0:未记账1:已记账
     */
    private Integer shopBillStatus;

    /**
     * 上游记账状态0:未记账1:已记账
     */
    private Integer upstreamBillStatus;

    /**
     * MQ消息状态
     */
    private Integer msgStatus;


    /**
     * MQ消息状态
     */
    private Integer returnCount;

    /**
     * 省份
     */
    private String province;

    /**
     * 城市
     */
    private String city;


}
