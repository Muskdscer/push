package com.request.schedule;

import com.alibaba.fastjson.JSONObject;
import com.request.common.constants.ParamConstants;
import com.request.common.constants.RedisConstant;
import com.request.common.enums.ShopTypeEnum;
import com.request.common.enums.StompSwitchEnum;
import com.request.config.system.SystemConfig;
import com.request.config.thread.ServerConfigurer;
import com.request.entity.PhoneOrderWaitPush;
import com.request.service.PushPackageOrderProcessor;
import com.request.service.RedisService;
import com.request.service.holder.PushOrderProcessorHolder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Description:
 * Create DateTime: 2020-04-01 16:04
 *
 * 

 */
@Slf4j
@Component
public class PushRequest {

    @Resource
    private ServerConfigurer serverConfigurer;

    @Resource
    private RedisService redisService;

    @Resource
    private SystemConfig systemConfig;

    @Resource
    private PushOrderProcessorHolder pushOrderProcessorHolder;

    @Resource
    private PushPackageOrderProcessor pushPackageOrderProcessor;

    @Scheduled(cron = "0/2 * * * * ?")
    public void waitPushOrderTask() {
        Long size = redisService.getListSize(RedisConstant.PUSH_ORDER_WAIT_PUSH);

        //redis里面没有要消费的数据
        if (size == null || size == 0) {
            return;
        }
        int handlerMaxSize = serverConfigurer.getHandlerMaxSize();
        if (size > handlerMaxSize) {
            size = (long) handlerMaxSize;
        }

        List<PhoneOrderWaitPush> phoneOrderWaitPushList = new ArrayList<>(size.intValue());

        for (int i = 0; i < size; i++) {
            Object obj = redisService.rPop(RedisConstant.PUSH_ORDER_WAIT_PUSH);
            if (obj != null) {
                PhoneOrderWaitPush phoneOrderWaitPush = JSONObject.parseObject(obj.toString(), PhoneOrderWaitPush.class);
                phoneOrderWaitPushList.add(phoneOrderWaitPush);
            }
        }

        Map<String, List<PhoneOrderWaitPush>> phoneOrderWaitPushMap = phoneOrderWaitPushList.stream().collect(Collectors.groupingBy(PhoneOrderWaitPush::getClassifyName));

        /*String pushType = systemConfig.getParam(ParamConstants.KX_DISTRIBUTE_ORDER_PUSH_TYPE);

        phoneOrderWaitPushMap.forEach((key, value) -> {

            if (!"KxDistribute".equals(key)) {
                for (PhoneOrderWaitPush phoneOrderWaitPush : value) {
                    pushOrderProcessorHolder.findPushOrderProcessor(ShopTypeEnum.getByEnName(phoneOrderWaitPush.getClassifyName())).sendRequest(phoneOrderWaitPush);
                }
            } else {
                if (PushTypeEnum.SINGLE.getCode().equals(pushType)) {
                    for (PhoneOrderWaitPush phoneOrderWaitPush : value) {
                        pushOrderProcessorHolder.findPushOrderProcessor(ShopTypeEnum.getByEnName(phoneOrderWaitPush.getClassifyName())).sendRequest(phoneOrderWaitPush);
                    }
                } else if (PushTypeEnum.PACKAGE.getCode().equals(pushType)) {
                    pushPackageOrderProcessor.sendRequest(value);
                }
            }
        });*/

        String stompSwitch = systemConfig.getParam(ParamConstants.KX_DISTRIBUTE_ORDER_STOMP_SWITCH);

        phoneOrderWaitPushMap.forEach((key, value) -> {

            if (!"KxDistribute".equals(key)) {
                for (PhoneOrderWaitPush phoneOrderWaitPush : value) {
                    pushOrderProcessorHolder.findPushOrderProcessor(ShopTypeEnum.getByEnName(phoneOrderWaitPush.getClassifyName())).sendRequest(phoneOrderWaitPush);
                }
            } else {
                if (StompSwitchEnum.DISABLE.getCode().equals(stompSwitch)) {
                    for (PhoneOrderWaitPush phoneOrderWaitPush : value) {
                        pushOrderProcessorHolder.findPushOrderProcessor(ShopTypeEnum.getByEnName(phoneOrderWaitPush.getClassifyName())).sendRequest(phoneOrderWaitPush);
                    }
                }
            }
        });
    }
}
