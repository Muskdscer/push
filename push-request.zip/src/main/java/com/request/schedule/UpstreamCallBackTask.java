package com.request.schedule;

import com.request.service.UpstreamCallBackService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * Description:
 * Create DateTime: 2020-04-02 17:45
 *
 * 

 */
@Component
@Slf4j
public class UpstreamCallBackTask {




    @Resource
    private UpstreamCallBackService upstreamCallBackService;

    /**
     * 渠道回调任务
     */
    @Scheduled(cron = "* * * * * ?")
//    @Scheduled(cron = "0/1 * * * * ? ")
    public void handlerUpstreamCallBack() {
//        log.info("【渠道回调】操作开始:{}====个数{}", DateUtil.dateToString(new Date(), "yyyy-MM-dd HH:mm:ss"));

        upstreamCallBackService.handlerUpstreamCallBack();
//        log.info("【渠道回调】操作结束:{}====个数{}", DateUtil.dateToString(new Date(), "yyyy-MM-dd HH:mm:ss"));

    }
}
