package com.request.schedule;

import com.alibaba.fastjson.JSONObject;
import com.request.common.constants.RedisConstant;
import com.request.common.enums.ShopTypeEnum;
import com.request.config.thread.ServerConfigurer;
import com.request.entity.PhoneOrderWaitCheck;
import com.request.service.RedisService;
import com.request.service.holder.QueryOrderProcessorHolder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * Description:
 * Create DateTime: 2020-04-01 16:05
 *
 * 

 */
@Component
@Slf4j
public class QueryOrderTask {

    @Resource
    private RedisService redisService;

    @Resource
    private ServerConfigurer serverConfigurer;

    @Resource
    private QueryOrderProcessorHolder queryOrderProcessorHolder;

    /**
     * 处理超时待查询的订单
     */
    @Scheduled(fixedDelay = 500)
    public void waitQueryOrderTask() {
        Long listSize = redisService.getListSize(RedisConstant.PUSH_ORDER_WAIT_CHECK);

        if (listSize == null || listSize == 0) {
            return;
        }

        if (listSize > serverConfigurer.getHandlerMaxSize()) {
            listSize = (long) serverConfigurer.getHandlerMaxSize();
        }
        for (int i = 0; i < listSize; i++) {
            Object object = redisService.rPop(RedisConstant.PUSH_ORDER_WAIT_CHECK);
            if (object != null) {
                PhoneOrderWaitCheck orderWaitCheck = JSONObject.parseObject(object.toString(), PhoneOrderWaitCheck.class);
                queryOrderProcessorHolder.findPushOrderProcessor(ShopTypeEnum.getByEnName(orderWaitCheck.getClassifyName())).sendRequest(orderWaitCheck);
            }
        }
    }
}
