package com.request.service.impl.shop.test;

import cn.hutool.core.bean.BeanUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.request.common.constants.RedisConstant;
import com.request.common.enums.SignTypeEnum;
import com.request.common.enums.TestErrorCodeEnum;
import com.request.common.utils.HttpUtils;
import com.request.common.utils.SignUtils;
import com.request.entity.PhoneOrderAvailable;
import com.request.entity.PhoneOrderWaitPush;
import com.request.entity.out.PushOrderForTest;
import com.request.service.PushOrderProcessor;
import com.request.service.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Description:
 * Create DateTime: 2020-04-23 10:42
 *
 * 

 */
@Slf4j
@Service
public class TestPushOrderProcessor implements PushOrderProcessor {


    @Resource
    private RedisService redisService;
    @Resource
    private ThreadPoolExecutor handlerOrderExecutor;

    @Resource
    private RedisTemplate<String, String> redisTemplate;

    @Override
    public void sendRequest(PhoneOrderWaitPush phoneOrderWaitPush) {
        handlerOrderExecutor.execute(() -> executeSend(phoneOrderWaitPush));
    }

    private void executeSend(PhoneOrderWaitPush phoneOrderWaitPush) {
        String result = null;
        PhoneOrderAvailable pa = phoneOrderWaitPush.getPhoneOrderAvailable();
        PushOrderForTest pushOrderForTest = new PushOrderForTest();
        try {


            TreeMap<String, String> signMap = new TreeMap<>();
            signMap.put("a", phoneOrderWaitPush.getAppKey());
            signMap.put("b", phoneOrderWaitPush.getAppId());
            signMap.put("c", pa.getPlatformOrderNo());
            signMap.put("d", pa.getPhoneNum());
            signMap.put("e", pa.getOrderPrice().toPlainString());
            signMap.put("f", pa.getPhoneOperator());
            signMap.put("g", phoneOrderWaitPush.getAppKey());
            String sign = SignUtils.generateSignature(signMap, SignTypeEnum.SHA256);
            pushOrderForTest.setOrderExpireTime(pa.getOrderExpireTime())
                    .setOrderPrice(pa.getOrderPrice())
                    .setPhoneNum(pa.getPhoneNum())
                    .setPhoneOperator(pa.getPhoneOperator())
                    .setAppId(phoneOrderWaitPush.getAppId())
                    .setSign(sign)
                    .setOrderNo(pa.getPlatformOrderNo())
                    .setProvince(pa.getProvince())
                    .setCity(pa.getCity());

            try {
                log.info("【测试】测试推送参数:{}", pushOrderForTest.toString());
                result = sendRequestForPushOrder(phoneOrderWaitPush.getPushSite(), pushOrderForTest);
                log.info("【测试】测试推送返回参数:{}", result);
            } catch (Exception e) {
                savePushOrderForException(phoneOrderWaitPush);
                savePushOrderForSuccess(pa.getPlatformOrderNo());
                log.info("【测试】【推单】发送请求出现异常：", e);
                return;
            }

            JSONObject jsonResult = JSON.parseObject(result);
            String code = jsonResult.getString("code");

            if (TestErrorCodeEnum.FAIL.getCode().equals(code)) {
                log.info("【Hf】【推单】响应状态失败,状态为：{}", code);
                savePushOrderForFailed(phoneOrderWaitPush);
                return;
            }
            if (!TestErrorCodeEnum.SUCCESS.getCode().equals(code)) {
                String msg = jsonResult.getString("msg");
                throw new RuntimeException("推送订单商户相应失败，相应的状态码为 : "+ code + ",对应的信息为 : " + msg + ",订单号为：{}" + pa.getPlatformOrderNo());
            }
            savePushOrderForSuccess(pa.getPlatformOrderNo());
        } catch (Exception e) {
            savePushOrderForSuccess(pa.getPlatformOrderNo());
            log.error("【测试】【推送订单】推送订单失败，待推送订单信息为：{}, 请求参数为：{}, 商户响应结果为：{}, 详细错误信息为：",
                    phoneOrderWaitPush, pushOrderForTest, result, e);
        }
    }

    /**
     * 发送Http请求
     *
     * @param url              请求路径
     * @param pushOrderForTest 参数
     * @return 响应结果
     */
    private String sendRequestForPushOrder(String url, PushOrderForTest pushOrderForTest) {
        Map<String, Object> paramMap = BeanUtil.beanToMap(pushOrderForTest);
        String paramJson = JSON.toJSONString(paramMap);
        return HttpUtils.jsonPost(url, paramJson);
    }

    /**
     * 放入失败队列
     */
    private void savePushOrderForFailed(PhoneOrderWaitPush phoneOrderWaitPush) {
        redisService.lPush(RedisConstant.PUSH_ORDER_WAIT_PUSH_RECORD, JSON.toJSONString(phoneOrderWaitPush));
    }

    /**
     * 放入成功队列
     */
    private void savePushOrderForSuccess(String platformOrderNo) {
        redisTemplate.opsForValue().set(RedisConstant.PUSH_ORDER_WAIT_PUSH_SUCCESS + platformOrderNo, platformOrderNo, 30, TimeUnit.MINUTES);
    }

    /**
     * 放入发送出现异常的队列
     */
    private void savePushOrderForException(PhoneOrderWaitPush phoneOrderWaitPush) {
        redisService.lPush(RedisConstant.PUSH_ORDER_WAIT_PUSH_EXCEPTION, JSON.toJSONString(phoneOrderWaitPush));
    }
}
