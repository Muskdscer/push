package com.request.service.impl.shop.newyicheng;

import cn.hutool.core.bean.BeanUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.request.common.constants.RedisConstant;
import com.request.common.enums.SignTypeEnum;
import com.request.common.utils.HttpUtils;
import com.request.common.utils.SignUtils;
import com.request.entity.PhoneOrderAvailable;
import com.request.entity.PhoneOrderWaitPush;
import com.request.entity.out.PushOrderForNewYiCheng;
import com.request.service.PushOrderProcessor;
import com.request.service.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Description:
 * Create DateTime: 2020-04-22 16:09
 *
 * 

 */
@Slf4j
@Service
public class NewYiChengPushOrderProcessor implements PushOrderProcessor {

    private static Map<String, String> HEADER_MAP = new HashMap<>(2);

    static {
        HEADER_MAP.put("Accept", "application/json;charset=utf-8");
    }

    @Resource
    private RedisService redisService;
    @Resource
    private ThreadPoolExecutor handlerOrderExecutor;

    @Resource
    private RedisTemplate<String, String> redisTemplate;

    @Override
    public void sendRequest(PhoneOrderWaitPush phoneOrderWaitPush) {
        handlerOrderExecutor.execute(() -> executeSend(phoneOrderWaitPush));
    }

    private void executeSend(PhoneOrderWaitPush phoneOrderWaitPush) {
        if (phoneOrderWaitPush == null) {
            return;
        }

        PhoneOrderAvailable phoneOrderAvailable = phoneOrderWaitPush.getPhoneOrderAvailable();
        PushOrderForNewYiCheng pushOrderForNewYiCheng = new PushOrderForNewYiCheng();
        String result = null;
        try {

            //组装参数
            pushOrderForNewYiCheng.setPhone(phoneOrderAvailable.getPhoneNum());
            pushOrderForNewYiCheng.setNum(phoneOrderAvailable.getOrderPrice().setScale(0));
            pushOrderForNewYiCheng.setKey(phoneOrderWaitPush.getAppId());
            pushOrderForNewYiCheng.setOrder_id(phoneOrderAvailable.getPlatformOrderNo());

            //生成签名
            TreeMap<String, String> signMap = new TreeMap<>();
            signMap.put("a", phoneOrderWaitPush.getAppKey());
            signMap.put("b", phoneOrderWaitPush.getAppId());
            signMap.put("c", pushOrderForNewYiCheng.getPhone());
            signMap.put("d", pushOrderForNewYiCheng.getNum().toPlainString());
            signMap.put("e", pushOrderForNewYiCheng.getOrder_id());

            String sign = SignUtils.generateSignature(signMap, SignTypeEnum.MD5);
            pushOrderForNewYiCheng.setSign(sign);

            try {
                result = sendRequestForPushOrder(phoneOrderWaitPush.getPushSite(), pushOrderForNewYiCheng);
            } catch (Exception e) {
                savePushOrderForException(phoneOrderWaitPush);
                log.info("【新翼程】【推单】发送请求出现异常：", e);
                return;
            }

            JSONObject json = JSONObject.parseObject(result);
            String errorCode = json.getString("error_code");

            if (!"0".equals(errorCode)) {
                log.info("【新翼程】【推单】响应状态失败,状态为：{}", errorCode);
                savePushOrderForFailed(phoneOrderWaitPush);
                return;
            }
            savePushOrderForSuccess(phoneOrderAvailable.getPlatformOrderNo());
        } catch (Exception e) {
            savePushOrderForSuccess(phoneOrderAvailable.getPlatformOrderNo());
            log.error("【新翼程】【推送订单】推送订单失败，待推送订单信息为：{}, 请求参数为：{}, 商户响应结果为：{}, 详细错误信息为：",
                    phoneOrderWaitPush, pushOrderForNewYiCheng, result, e);
        }
    }

    /**
     * 发送Http请求
     *
     * @param url                 请求路径
     * @param pushOrderForNewYiCheng 参数
     * @return 响应结果
     */
    private String sendRequestForPushOrder(String url, PushOrderForNewYiCheng pushOrderForNewYiCheng) {
        Map<String, Object> paramMap = BeanUtil.beanToMap(pushOrderForNewYiCheng);
        return HttpUtils.doGet(url, paramMap);
    }

    /**
     * 放入失败队列
     */
    private void savePushOrderForFailed(PhoneOrderWaitPush phoneOrderWaitPush) {
        redisService.lPush(RedisConstant.PUSH_ORDER_WAIT_PUSH_RECORD, JSON.toJSONString(phoneOrderWaitPush));
    }

    /**
     * 放入成功队列
     */
    private void savePushOrderForSuccess(String platformOrderNo) {
        redisTemplate.opsForValue().set(RedisConstant.PUSH_ORDER_WAIT_PUSH_SUCCESS + platformOrderNo, platformOrderNo, 30, TimeUnit.MINUTES);
    }

    /**
     * 放入发送出现异常的队列
     */
    private void savePushOrderForException(PhoneOrderWaitPush phoneOrderWaitPush) {
        redisService.lPush(RedisConstant.PUSH_ORDER_WAIT_PUSH_EXCEPTION, JSON.toJSONString(phoneOrderWaitPush));
    }

}
