package com.request.service.impl.shop.newyicheng;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.request.common.constants.RedisConstant;
import com.request.common.enums.NewYiChengStatusEnum;
import com.request.common.enums.RechargeTypeEnum;
import com.request.common.utils.HttpUtils;
import com.request.entity.PhoneOrderWaitCheck;
import com.request.service.QueryOrderProcessor;
import com.request.service.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * Description:
 * Create DateTime: 2020-04-22 17:25
 *
 * 

 */
@Slf4j
@Service
public class NewYiChengQueryOrderProcessor implements QueryOrderProcessor {

    private static Map<String, String> HEADER_MAP = new HashMap<>(2);

    static {
        HEADER_MAP.put("Accept", "application/json;charset=utf-8");
    }

    @Resource
    private RedisService redisService;
    @Resource
    private ThreadPoolExecutor handlerOrderExecutor;

    @Override
    public void sendRequest(PhoneOrderWaitCheck orderWaitCheck) {
        handlerOrderExecutor.execute(() -> executeWaitOrderQuery(orderWaitCheck));
    }

    /**
     * 执行待查询订单查询
     *
     * @param phoneOrderWaitCheck 待查询订单
     */
    private void executeWaitOrderQuery(PhoneOrderWaitCheck phoneOrderWaitCheck) {
        Map<String, Object> params = new HashMap<>();
        String result = null;
        try {
            if (phoneOrderWaitCheck == null) {
                return;
            }

            params.put("key", phoneOrderWaitCheck.getAppId());
            params.put("order_id", phoneOrderWaitCheck.getPlatformOrderNo());

            result = sendRequestForWaitOrder(phoneOrderWaitCheck.getQuerySite(), params);
            log.info("【新翼城】查询请求返回参数:{}", result);
            JSONObject jsonObject = JSON.parseObject(result);
            String errorCode = jsonObject.getString("error_code");
            //请求成功返回0
            if ("0".equals(errorCode))  {
                JSONObject data = jsonObject.getJSONObject("result");

                phoneOrderWaitCheck.setShopOrderNo(data.getString("sys_order_id"));

                String status = data.getString("status");

                NewYiChengStatusEnum statusEnum = NewYiChengStatusEnum.getByCode(status);

                switch (statusEnum) {
                    case SUCCESS:
                        phoneOrderWaitCheck.setStatus(1);
                        saveWaitOrderQueryForSuccess(phoneOrderWaitCheck);
                        break;
                    case FAIL:
                        phoneOrderWaitCheck.setStatus(0);
                        saveWaitOrderQueryForSuccess(phoneOrderWaitCheck);
                        break;
                    case RECHARGING:
                        saveWaitOrderQueryForProcessing(phoneOrderWaitCheck);
                        break;
                    default:
                        saveWaitOrderQueryForProcessing(phoneOrderWaitCheck);
                        break;
                }
            }
        } catch (Exception e) {
            saveWaitOrderQueryForProcessing(phoneOrderWaitCheck);
            log.error("【翼程】【超时检查】请求商户出现异常，待检查订单信息为：{}, 参数为：{}, 响应结果为:{}, 详情为：{}",
                    phoneOrderWaitCheck, params.toString(), result, e);
        }
    }

    /**
     * 发送Http请求
     *
     * @param url    请求路径
     * @param params 参数
     * @return 响应结果
     */
    private String sendRequestForWaitOrder(String url, Map<String, Object> params) {
        return HttpUtils.doGet(url, params);
    }

    /**
     * 放入成功队列
     */
    private void saveWaitOrderQueryForSuccess(PhoneOrderWaitCheck phoneOrderWaitCheck) {
        redisService.lPush(RedisConstant.PUSH_ORDER_WAIT_CHECK_SUCCESS, JSON.toJSONString(phoneOrderWaitCheck));
    }

    /**
     * 放入处理中队列
     */
    private void saveWaitOrderQueryForProcessing(PhoneOrderWaitCheck phoneOrderWaitCheck) {
        if (!RechargeTypeEnum.SLOW.getCode().equals(phoneOrderWaitCheck.getRechargeType())) {
            redisService.lPush(RedisConstant.PUSH_ORDER_WAIT_CHECK_PROCESSING, JSON.toJSONString(phoneOrderWaitCheck));
        }
    }
}
