package com.request.service.holder;

import com.request.common.enums.ShopTypeEnum;
import com.request.common.webfacade.error.CommonException;
import com.request.common.webfacade.error.ErrorEnum;
import com.request.service.PushOrderProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Description:
 * Create DateTime: 2020-04-22 16:07
 *
 * 

 */
@Component
public class PushOrderProcessorHolder {

    @Autowired
    private Map<String, PushOrderProcessor> pushOrderProcessors;

    /**
     * 获取Shop处理器
     *
     * @param type 商户类别
     * @return 对应的商户处理器
     */
    public PushOrderProcessor findPushOrderProcessor(ShopTypeEnum type) {
        if (type == null) {
            return null;
        }
        return findPushOrderProcessor(type.getClassPre());
    }

    private PushOrderProcessor findPushOrderProcessor(String type) {
        String className = generateClassName(type);
        PushOrderProcessor pushOrderProcessor = pushOrderProcessors.get(className);
        if (pushOrderProcessor == null) {
            throw new CommonException(ErrorEnum.COMMON_BUSINESS_ERROR);
        }
        return pushOrderProcessor;
    }

    private String generateClassName(String type) {
        return type + PushOrderProcessor.class.getSimpleName();
    }

}
