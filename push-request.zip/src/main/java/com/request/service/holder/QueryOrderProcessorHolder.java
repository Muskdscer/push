package com.request.service.holder;

import com.request.common.enums.ShopTypeEnum;
import com.request.common.webfacade.error.CommonException;
import com.request.common.webfacade.error.ErrorEnum;
import com.request.service.QueryOrderProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Description:
 * Create DateTime: 2020-04-22 16:53
 *
 * 

 */
@Component
public class QueryOrderProcessorHolder {

    @Autowired
    private Map<String, QueryOrderProcessor> queryOrderProcessors;

    /**
     * 获取Shop处理器
     *
     * @param type 商户类别
     * @return 对应的商户处理器
     */
    public QueryOrderProcessor findPushOrderProcessor(ShopTypeEnum type) {
        if (type == null) {
            return null;
        }
        return findPushOrderProcessor(type.getClassPre());
    }

    private QueryOrderProcessor findPushOrderProcessor(String type) {
        String className = generateClassName(type);
        QueryOrderProcessor queryOrderProcessor = queryOrderProcessors.get(className);
        if (queryOrderProcessor == null) {
            throw new CommonException(ErrorEnum.COMMON_BUSINESS_ERROR);
        }
        return queryOrderProcessor;
    }

    private String generateClassName(String type) {
        return type + QueryOrderProcessor.class.getSimpleName();
    }
}
