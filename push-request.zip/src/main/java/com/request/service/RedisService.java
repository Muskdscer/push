package com.request.service;

import java.util.List;
import java.util.Map;

public interface RedisService {

    /**
     * 获取list队列的长度
     *
     * @param key 键
     * @return 长度
     */
    Long getListSize(String key);

    /**
     * 入队
     *
     * @param key   键
     * @param value 值
     */
    void lPush(String key, String value);

    /**
     * 出栈
     *
     * @param key 键
     * @return 值
     */
    Object rPop(String key);

    /**
     * 范围查询
     *
     * @param key   键
     * @param start 0
     * @param end   -1 即全部
     * @return 数据
     */
    List<String> range(String key, int start, int end);

    /**
     * @param key   redis key
     * @param start 从list那边查找
     * @param value 哪个值
     */
    void removeListByValue(String key, int start, String value);

    /**
     * @param sourceKey
     * @param destinationKey
     */
    void rightPopAndLeftPush(String sourceKey, String destinationKey);

    /**
     * 从Hash中取出key下所有field
     *
     * @param key key
     * @return key下所有field
     */
    Map<Object, Object> hGetAll(String key);
}
