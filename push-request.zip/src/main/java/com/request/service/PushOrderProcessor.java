package com.request.service;

import com.request.entity.PhoneOrderWaitPush;

/**
 * Description:
 * Create DateTime: 2020-04-22 16:08
 *
 * 

 */
public interface PushOrderProcessor {

    /**
     * 推单发送请求
     *
     * @param phoneOrderWaitPush 待推送订单
     */
    void sendRequest(PhoneOrderWaitPush phoneOrderWaitPush);

}
