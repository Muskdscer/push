package com.request.service;

import com.request.entity.PhoneOrderWaitCheck;

/**
 * Description:
 * Create DateTime: 2020-04-22 16:53
 *
 * 

 */
public interface QueryOrderProcessor {

    /**
     * 推单发送查询订单请求
     *
     * @param orderWaitCheck 待查询订单
     */
    void sendRequest(PhoneOrderWaitCheck orderWaitCheck);

}
