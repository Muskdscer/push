package com.request.service;

/**
 * Description:
 * Create DateTime: 2020-04-02 18:00
 *
 * 

 */
public interface UpstreamCallBackService {

    /**
     * 处理渠道回调
     */
    void handlerUpstreamCallBack();
}
