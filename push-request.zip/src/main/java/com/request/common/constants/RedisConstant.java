package com.request.common.constants;

/**
 * Description: Redis常量
 * Create DateTime: 2020-03-24 13:54
 *
 * 

 */
public interface RedisConstant {

    /**
     * session登录用户
     */
    String PUSH_ORDER_SESSION_LOGIN_USER_PRE_KEY = "push-order:loginUser:session:";

    /**
     * token登录用户
     */
    String PUSH_ORDER_TOKEN_LOGIN_USER_PRE_KEY = "push-order:loginUser:token:";

    /**
     * 系统参数key
     */
    String PUSH_ORDER_SYSTEM_PARAM = "push-order:systemParam";

    /**
     * 待推送订单
     */
    String PUSH_ORDER_WAIT_PUSH = "push-order:waitPush";

    /**
     * 待推送订单回调成功
     */
    String PUSH_ORDER_WAIT_PUSH_SUCCESS = "push-order:waitPush:success:";

    /**
     * 待推送订单前置成功
     */
    String PUSH_ORDER_WAIT_PUSH_PRE_SUCCESS = "push-order:waitPush:preSuccess";

    /**
     * 待推送订单回调记录
     */
    String PUSH_ORDER_WAIT_PUSH_RECORD = "push-order:waitPush:record";

    /**
     * 待推送订单出现异常
     */
    String PUSH_ORDER_WAIT_PUSH_EXCEPTION = "push-order:waitPush:exception";

    /**
     * 超时待检查订单
     */
    String PUSH_ORDER_WAIT_CHECK = "push-order:waitCheck";

    /**
     * 超时待检查订单回调成功
     */
    String PUSH_ORDER_WAIT_CHECK_SUCCESS = "push-order:waitCheck:success";

    /**
     * 超时待检查订单回调失败
     */
    String PUSH_ORDER_WAIT_CHECK_FAILED = "push-order:waitCheck:failed";

    /**
     * 超时待检查订单回调处理中
     */
    String PUSH_ORDER_WAIT_CHECK_PROCESSING = "push-order:waitCheck:processing";

    /**
     * 待回调渠道订单
     */
    String PUSH_ORDER_UP_STREAM_WAIT_CALL_BACK = "push-order:upStreamWaitCallBack";

    /**
     * 待回调渠道订单-成功
     */
    String PUSH_ORDER_UP_STREAM_WAIT_CALL_BACK_SUCCESS = "push-order:upStreamCallBack:success";

    /**
     * 待回调渠道订单-失败
     */
    String PUSH_ORDER_UP_STREAM_WAIT_CALL_BACK_FAILED = "push-order:upStreamCallBack:failed";

    /**
     * 数据商下单成功结果队列
     */
    String PUSH_ORDER_SJ_SUCCESS_WITH_SHOP_ORDER_NO = "push-order:waitPush:success:sj";
}
