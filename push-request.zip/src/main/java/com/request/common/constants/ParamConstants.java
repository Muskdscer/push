package com.request.common.constants;

/**
 * Description:
 * Create DateTime: 2020/9/1 15:33
 *
 * 

 */
public interface ParamConstants {

    /**
     * 魁信配单stomp开关
     */
    String KX_DISTRIBUTE_ORDER_STOMP_SWITCH = "KX_DISTRIBUTE_ORDER_STOMP_SWITCH";

    /**
     * 魁信配单发送订单方式
     */
    String KX_DISTRIBUTE_ORDER_PUSH_TYPE = "KX_DISTRIBUTE_ORDER_PUSH_TYPE";

}
