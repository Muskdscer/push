package com.request.common.constants;

public class Constants {

    /**
     * 第三方接口缓存redis的key
     */
    public static final String BOYE_PROVIDE = "boye_provide";
    /**
     * 字典项的key
     */
    public static final String BOYE_DICT = "boye_dict";

    /**
     * 账户可用额度放入缓存key
     */
    public static final String BOYE_PAYMENTACCOUNT = "new_paymentaccount";

    /**
     * 判断公共参数
     */
    public static final String STRING_ZERO = "0";

    public static final String STRING_ONE = "1";
    /**
     * 商家异步回调特殊处理标识
     */
    public static final String TIMEOUT_FAIL = "timeOutfail";

    /**
     * 支付待处理队列
     */
    public static final String BOYE_CPORDERINFO = "boye_cporderinfo";

    /**
     * 支付待处理队列 2
     */
    public static final String BOYE_CPORDERINFO_TWO = "boye_cporderinfo_two";

    /**
     * 支付处理成功队列
     */
    public static final String BOYE_CPORDER_SUCCESS = "boye_cporder_success";
    /**
     * 支付处理失败队列
     */
    public static final String BOYE_CPORDER_FAIL = "boye_cporder_fail";


    /**
     * redis支付待处理缓存队列 存储id防止redis内存不足
     */
    public static final String CPORDER_IDS = "cporder_ids";

}
