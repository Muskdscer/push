package com.request.common.enums;

import lombok.Getter;

/**
 * Description:
 * Create DateTime: 2020/4/20 17:12
 *
 * 

 */
@Getter
public enum JHErrorCodeEnum {

    PROCESSING(0, "正在充值"),

    MISS_PARAM(20, "缺少参数，或者参数类型错误"),

    NOT_HAVE_INTERFACE(21, "没有开通此接口或者interfacekey不正确"),

    EXCEED_MAXVALUE(22, "一次委托最多2000张卡"),

    SIGN_NOT_PASS(23, "签名认证不通过"),

    ORDER_NUMBER_REPENT(24, "订单号重复"),

    INTERFACE_NOT_ABLE(25, "当前接口设置暂停委托状态"),

    PHONE_NUMBER_ERROR(26, "充值卡卡号有误"),

    BALANCE_NOT_ADEQUATE(27, "平台余额不充足,请充值"),

    IP_ERROR(28, "不是绑定的ip地址请求");

    private Integer code;
    private String data;

    JHErrorCodeEnum(Integer code, String data) {
        this.code = code;
        this.data = data;
    }

    public static JHErrorCodeEnum getByValue(Integer value) {
        if (value != null) {
            for (JHErrorCodeEnum enu : values()) {
                if (enu.code.equals(value)) {
                    return enu;
                }
            }
        }
        return null;
    }
}
