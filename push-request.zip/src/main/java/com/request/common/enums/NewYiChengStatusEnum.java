package com.request.common.enums;

import lombok.Getter;

/**
 * Description:
 * Create DateTime: 2020/4/20 17:12
 *
 * 

 */
@Getter
public enum NewYiChengStatusEnum {

    RECHARGING("0", "充值中"),

    SUCCESS("1", "成功"),

    FAIL("9", "失败"),
    ;

    String status;

    String data;

    NewYiChengStatusEnum(String code, String data) {
        this.status = code;
        this.data = data;
    }

    public static NewYiChengStatusEnum getByCode(String status) {
        for (NewYiChengStatusEnum newYiChengStatusEnum : values()) {
            if(newYiChengStatusEnum.getStatus().equals(status)) {
                return newYiChengStatusEnum;
            }
         }
        return null;
    }
}
