package com.request.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Description:
 * Create DateTime: 2020/9/1 15:34
 *
 * 

 */
@Getter
@AllArgsConstructor
public enum PushTypeEnum {

    SINGLE("0", "单条发送"),

    PACKAGE("1", "打包发送");

    String code;

    String desc;

}
