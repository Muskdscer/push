package com.request.common.enums;

import lombok.Getter;

@Getter
public enum RechargeTypeEnum {


    QUICK(0, "快充"),

    SLOW(1, "慢充");


    Integer code;
    String message;

    RechargeTypeEnum(Integer code, String message) {
        this.code = code;
        this.message = message;
    }

}
