package com.request.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.Optional;

/**
 * Description:
 * Create DateTime: 2020/4/24 13:53
 *
 * 

 */
@Getter
@AllArgsConstructor
public enum KxDistributeOrderStatusEnum {

    SUCCESS("1", "成功"),

    FAILED("2", "失败"),

    PROCESSING("0", "处理中"),
    ;

    String code;

    String msg;

    public static KxDistributeOrderStatusEnum getByCode(String code) {
        if (StringUtils.isBlank(code)) {
            return null;
        }
        Optional<KxDistributeOrderStatusEnum> first = Arrays.stream(values())
                .filter(item -> item.getCode().equals(code))
                .findFirst();
        if (first.isEmpty()) {
            return null;
        }
        return first.get();
    }
}
