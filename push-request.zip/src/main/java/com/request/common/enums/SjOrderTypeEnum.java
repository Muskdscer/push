package com.request.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 * Description:
 * Create DateTime: 2020/7/24 17:25
 *
 * 

 */
@Getter
@NoArgsConstructor
@AllArgsConstructor
public enum SjOrderTypeEnum {

    FAST(1, "快充"),

    SLOW(2, "慢充");


    private int code;

    private String desc;

}
