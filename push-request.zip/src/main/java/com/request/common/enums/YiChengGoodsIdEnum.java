package com.request.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.Optional;

/**
 * Description:
 * Create DateTime: 2020-04-23 17:20
 *
 * 

 */
@Getter
@AllArgsConstructor
public enum YiChengGoodsIdEnum {

    //==========================移动==========================

    MOBILE_TEN(OperatorTypeEnum.MOBILE.getCode(), "10", "20000", false),

    MOBILE_TWENTY(OperatorTypeEnum.MOBILE.getCode(), "20", "20001", false),

    MOBILE_THIRTY(OperatorTypeEnum.MOBILE.getCode(), "30", "20002", false),

    MOBILE_FIFTY(OperatorTypeEnum.MOBILE.getCode(), "50", "20003", false),

    MOBILE_HUNDRED(OperatorTypeEnum.MOBILE.getCode(), "100", "20004", false),

    MOBILE_TWO_HUNDRED(OperatorTypeEnum.MOBILE.getCode(), "200", "20005", false),

    MOBILE_THREE_HUNDRED(OperatorTypeEnum.MOBILE.getCode(), "300", "20006", false),

    MOBILE_FIVE_HUNDRED(OperatorTypeEnum.MOBILE.getCode(), "500", "20007", false),

    //=========================联通============================

    UNICOM_TEN(OperatorTypeEnum.UNICOM.getCode(), "10", "20008", false),

    UNICOM_TWENTY(OperatorTypeEnum.UNICOM.getCode(), "20", "20009", false),

    UNICOM_THIRTY(OperatorTypeEnum.UNICOM.getCode(), "30", "20010", false),

    UNICOM_FIFTY(OperatorTypeEnum.UNICOM.getCode(), "50", "20011", false),

    UNICOM_HUNDRED(OperatorTypeEnum.UNICOM.getCode(), "100", "20012", false),

    UNICOM_TWO_HUNDRED(OperatorTypeEnum.UNICOM.getCode(), "200", "20013", false),

    UNICOM_THREE_HUNDRED(OperatorTypeEnum.UNICOM.getCode(), "300", "20014", false),

    //-------------------------沃-----------------------------

    UNICOM_WO_TEN(OperatorTypeEnum.UNICOM.getCode(), "10", "20023", true),

    UNICOM_WO_TWENTY(OperatorTypeEnum.UNICOM.getCode(), "20", "20024", true),

    UNICOM_WO_THIRTY(OperatorTypeEnum.UNICOM.getCode(), "30", "20025", true),

    UNICOM_WO_FIFTY(OperatorTypeEnum.UNICOM.getCode(), "50", "20026", true),

    UNICOM_WO_HUNDRED(OperatorTypeEnum.UNICOM.getCode(), "100", "20027", true),

    UNICOM_WO_TWO_HUNDRED(OperatorTypeEnum.UNICOM.getCode(), "200", "20028", true),

    UNICOM_WO_THREE_HUNDRED(OperatorTypeEnum.UNICOM.getCode(), "300", "20029", true),

    UNICOM_WO_FIVE_HUNDRED(OperatorTypeEnum.UNICOM.getCode(), "500", "20030", true),


    //========================电信==============================

    TELECOM_TEN(OperatorTypeEnum.TELECOM.getCode(), "10", "20015", false),

    TELECOM_TWENTY(OperatorTypeEnum.TELECOM.getCode(), "20", "20016", false),

    TELECOM_THIRTY(OperatorTypeEnum.TELECOM.getCode(), "30", "20017", false),

    TELECOM_FIFTY(OperatorTypeEnum.TELECOM.getCode(), "50", "20018", false),

    TELECOM_HUNDRED(OperatorTypeEnum.TELECOM.getCode(), "100", "20019", false),

    TELECOM_TWO_HUNDRED(OperatorTypeEnum.TELECOM.getCode(), "200", "20020", false),

    TELECOM_THREE_HUNDRED(OperatorTypeEnum.TELECOM.getCode(), "300", "20021", false),

    TELECOM_FIVE_HUNDRED(OperatorTypeEnum.TELECOM.getCode(), "500", "20022", false),

    //-------------------------翼-----------------------------

    TELECOM_Y_TEN(OperatorTypeEnum.TELECOM.getCode(), "10", "20031", true),

    TELECOM_Y_TWENTY(OperatorTypeEnum.TELECOM.getCode(), "20", "20032", true),

    TELECOM_Y_THIRTY(OperatorTypeEnum.TELECOM.getCode(), "30", "20033", true),

    TELECOM_Y_FIFTY(OperatorTypeEnum.TELECOM.getCode(), "50", "20034", true),

    TELECOM_Y_HUNDRED(OperatorTypeEnum.TELECOM.getCode(), "100", "20035", true),

    TELECOM_Y_TWO_HUNDRED(OperatorTypeEnum.TELECOM.getCode(), "200", "20036", true),

    TELECOM_Y_THREE_HUNDRED(OperatorTypeEnum.TELECOM.getCode(), "300", "20037", true),

    TELECOM_Y_FIVE_HUNDRED(OperatorTypeEnum.TELECOM.getCode(), "500", "20038", true),

    ;

    String phoneOperate;

    String orderPrice;

    String goodsId;

    Boolean isElse;

    public static YiChengGoodsIdEnum getByPhoneOperatorAndPrice(String phoneOperate, String orderPrice, Boolean isElse) {
        if (StringUtils.isNotBlank(phoneOperate)
                && StringUtils.isNotBlank(orderPrice)) {
            Optional<YiChengGoodsIdEnum> first = Arrays.stream(values()).filter(yiChengGoodsIdEnum -> yiChengGoodsIdEnum.getPhoneOperate().equals(phoneOperate)
                    && yiChengGoodsIdEnum.getOrderPrice().equals(orderPrice)
                    && yiChengGoodsIdEnum.getIsElse().equals(isElse))
                    .findFirst();
            if (first.isEmpty()) {
                return null;
            }
            return first.get();
        }
        return null;
    }
}
