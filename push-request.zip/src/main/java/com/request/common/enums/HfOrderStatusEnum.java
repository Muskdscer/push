package com.request.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.Optional;

/**
 * Description:
 * Create DateTime: 2020/4/24 13:53
 *
 * 

 */
@Getter
@AllArgsConstructor
public enum HfOrderStatusEnum {

    PROCESSING(0, "产码中"),

    CHARGING(1, "充值中"),

    FAILED(2, "充值失败"),

    SUCCESS(3, "充值成功"),

    TIMEOUT(4,"超时"),

    ;

    Integer code;

    String msg;

    public static HfOrderStatusEnum getByCode(Integer code) {
        if (code == null) {
            return null;
        }
        Optional<HfOrderStatusEnum> first = Arrays.stream(values())
                .filter(item -> item.getCode().equals(code))
                .findFirst();
        if (first.isEmpty()) {
            return null;
        }
        return first.get();
    }
}
