package com.request.common.enums;

import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

/**
 * Description:
 * Create DateTime: 2020-04-21 15:12
 *
 * 

 */
@Getter
public enum ShopTypeEnum {

    Test("测试", "Test", "test"),

    YiCheng("翼程", "YiCheng", "yiCheng"),

    NewYiCheng("新翼程", "NewYiCheng", "newYiCheng"),

    JH("JH", "JH", "jH"),

    Sy("Sy", "Sy", "sy"),

    Hf("Hf", "Hf", "hf"),

    Sj("Sj", "Sj", "sj"),

    KxDistribute("KxDistribute", "KxDistribute", "kxDistribute"),

    Happy("Happy", "Happy", "happy"),
    ;

    String name;

    String enName;

    String classPre;

    ShopTypeEnum(String name, String enName, String classPre) {
        this.name = name;
        this.enName = enName;
        this.classPre = classPre;
    }

    public static ShopTypeEnum getByEnName(String name) {
        if (StringUtils.isNotBlank(name)) {
            for (ShopTypeEnum enu : values()) {
                if (enu.enName.equals(name)) {
                    return enu;
                }
            }
        }
        return null;
    }
}
