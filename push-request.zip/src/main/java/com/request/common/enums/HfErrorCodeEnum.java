package com.request.common.enums;

import lombok.Getter;

/**
 * Description:
 * Create DateTime: 2020/5/22 12:00
 *
 * 

 */
@Getter
public enum HfErrorCodeEnum {

    FAIL("0", "失败"),

    SUCCESS("1", "成功")
    ;

    private String code;

    private String msg;

    HfErrorCodeEnum(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }
}
