package com.request.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.Optional;

/**
 * Description:
 * Create DateTime: 2020/4/24 13:53
 *
 * 

 */
@Getter
@AllArgsConstructor
public enum SyOrderStatusEnum {


    SUCCESS("1", "充值成功"),

    PUSH_ORDER_SUCCESS("1000", "下单成功"),

    PUSH_ORDER_FAIL("1010", "下单失败"),

    FAILED("1002", "充值失败"),

    PROCESSING("1003","处理中"),
    ;

    String code;

    String msg;

    public static SyOrderStatusEnum getByCode(String code) {
        if (code == null) {
            return null;
        }
        Optional<SyOrderStatusEnum> first = Arrays.stream(values())
                .filter(item -> item.getCode().equals(code))
                .findFirst();
        if (first.isEmpty()) {
            return null;
        }
        return first.get();
    }
}
