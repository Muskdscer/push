package com.request.common.enums;

import lombok.Getter;

/**
 * Description:
 * Create DateTime: 2020/4/21 10:26
 *
 * 

 */
@Getter
public enum UserTypeEnum {

    COMPANY(0, "COMPANY"),

    PERSONAL(1, "PERSONAL");


    private Integer code;
    private String data;

    UserTypeEnum(Integer code, String data) {
        this.code = code;
        this.data = data;
    }
}
