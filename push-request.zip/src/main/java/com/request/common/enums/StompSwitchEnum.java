package com.request.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Description:
 * Create DateTime: 2020/9/30 17:11
 *
 * 

 */
@Getter
@AllArgsConstructor
public enum StompSwitchEnum {

    DISABLE("0", "禁用"),

    ENABLE("1", "开启"),

    HTTP_PACKAGE("2", "打包发送请求");

    String code;

    String desc;

}
