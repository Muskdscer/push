package com.request.common.enums;

import lombok.Getter;

/**
 * Description:
 * Create DateTime: 2020/4/20 17:12
 *
 * 

 */
@Getter
public enum YiChengErrorCodeEnum {

    SUCCESS("00", "交易成功"),

    MISS_PARAM("10", "缺少参数，或者参数类型错误"),

    VALIDATE_CODE_FAILED("11", "校验码验证失败"),

    VALIDATE_IP_FAILED("12", "白名单校验失败"),

    GOODS_STATUS_ERROR("20", "商品状态相关错误"),

    GOODS_PRICE_ERROR("21", "商品价格错误"),

    ORDER_ERROR("22", "订单相关错误"),

    REPEAT_SERIAL_NO("23", "流水号重复"),

    PHONE_NOT_MATCH_OPERATOR("24", "手机号码与运营商区域不匹配"),

    PHONE_FORMAT_ERROR("25", "手机号格式不正确"),

    BLACK_ERROR("28", "黑名单相关错误"),

    UPSTREAM_SUPPLY_FAILED("30", "上游供货失败"),

    UPSTREAM_SUPPLY_TIME_OUT("31", "上游供货超时"),

    COOPERATION_ACCOUNT_ERROR("40", "合作方账号类型或者状态错误"),

    COOPERATION_FUND_ERROR("41", "合作方资金账户错误"),

    COOPERATION_NO_BALANCE("42", "合作方余额不足等错误"),

    COOPERATION_PAY_ERROR("43", "合作方支付错误"),

    COOPERATION_NOT_ACCESS("44", "合作方没有该业务权限"),

    ERROR("50", "系统异常"),

    BUSY_TRADING("51", "交易繁忙，上游供货繁忙"),

    REPEAT_FAILED_NUMBER("54", "请勿重复提交失败号码");

    String code;

    String data;

    YiChengErrorCodeEnum(String code, String data) {
        this.code = code;
        this.data = data;
    }

    public static YiChengErrorCodeEnum getByValue(Integer value) {
        if (value != null) {
            for (YiChengErrorCodeEnum enu : values()) {
                if (enu.code.equals(value)) {
                    return enu;
                }
            }
        }
        return null;
    }
}
