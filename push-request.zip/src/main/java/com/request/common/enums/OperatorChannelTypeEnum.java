package com.request.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.Optional;

/**
 * Description: 删除标识枚举
 * Create DateTime: 2020-03-26 14:30
 *
 * 

 */
@Getter
@AllArgsConstructor
public enum OperatorChannelTypeEnum {

    MOBILE("100", "移动"),

    UNICOM("200", "联通"),

    TELECOM("300", "电信"),

    WO("400", "沃"),

    YI("500", "翼");

    String code;

    String desc;

    public static OperatorChannelTypeEnum getByCode(String code) {
        if (StringUtils.isBlank(code)) {
            return null;
        }
        Optional<OperatorChannelTypeEnum> first = Arrays.stream(values())
                .filter(item -> item.getCode().equals(code))
                .findFirst();
        if (first.isEmpty()) {
            return null;
        }
        return first.get();
    }

}
