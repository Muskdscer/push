package com.request.common.enums;

import lombok.Getter;

import java.util.Arrays;
import java.util.Optional;

/**
 * Description:
 * Create DateTime: 2020/5/22 12:00
 *
 * 

 */
@Getter
public enum SjErrorCodeEnum {

    SUCCESS(200, "成功"),

    TIME_OUT(300, "异步通知 订单超时"),

    PARAM_IS_BLANK(400, "参数有误"),

    PARAM_SHOP_NOT_EXIST(401, "参数有误，商户不存在"),

    SIGN_ERROR(402, "参数有误，签名错误"),

    RECHARGE_AMOUNT_ERROR(403, "下单失败，充值金额有误"),

    NOT_SUPPORT_NUM_FIELD(404, "下单失败，暂不支持该号段"),

    SERVER_ERROR(500, "下单失败，系统异常"),

    SHOP_NON_ACTIVATED(501, "下单失败，商户未开通该功能"),

    SHOP_NOT_BALANCE(502, "下单失败，商户余额不足"),

    SHOP_CHANNEL_CLOSED(503, "下单失败，通道已关闭"),

    SELECT_SHOP_NOT_EXIST(601, "查询失败，商户不存在"),

    ORDER_NOT_EXIST(602, "查询失败，订单不存在"),

    ORDER_PAYING(603, "订单支付中，请稍候查询"),

    ORDER_NOT_PAY(604, "订单未支付"),
    ;

    private int code;

    private String msg;

    SjErrorCodeEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public static SjErrorCodeEnum getByCode(Integer code) {
        if (code == null) {
            return null;
        }
        Optional<SjErrorCodeEnum> first = Arrays.stream(values())
                .filter(item -> item.getCode() == code)
                .findFirst();
        if (first.isEmpty()) {
            return null;
        }
        return first.get();
    }
}
