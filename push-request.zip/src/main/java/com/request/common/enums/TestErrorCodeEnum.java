package com.request.common.enums;

import lombok.Getter;

/**
 * Description:
 * Create DateTime: 2020/5/22 12:00
 *
 * 

 */
@Getter
public enum TestErrorCodeEnum {

    FAIL("2", "失败"),

    SUCCESS("1", "成功")
    ;

    private String code;

    private String msg;

    TestErrorCodeEnum(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }
}
