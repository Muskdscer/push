package com.request.common.enums;

import lombok.Getter;

import java.util.Arrays;
import java.util.Optional;

/**
 * Description:
 * Create DateTime: 2020/5/22 12:00
 *
 * 

 */
@Getter
public enum HappyErrorCodeEnum {

    SUCCESS(0, "成功"),

    FAIL(101, "”参数缺失")
    ;

    private int code;

    private String msg;

    HappyErrorCodeEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public static HappyErrorCodeEnum getByCode(Integer code) {
        if (code == null) {
            return null;
        }
        Optional<HappyErrorCodeEnum> first = Arrays.stream(values())
                .filter(item -> item.getCode() == code)
                .findFirst();
        if (first.isEmpty()) {
            return null;
        }
        return first.get();
    }
}
