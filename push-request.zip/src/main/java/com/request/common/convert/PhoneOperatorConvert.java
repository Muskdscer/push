package com.request.common.convert;

/**
 * Description:
 * Create DateTime: 2020/4/21 10:45
 *
 * 

 */
public class PhoneOperatorConvert {
    public static String setPhoneOperator(String phoneOperator) {
        if (phoneOperator.equals("100")) {
            return "0031";
        } else if (phoneOperator.equals("200")) {
            return "0032";
        } else {
            return "0033";
        }
    }
}
