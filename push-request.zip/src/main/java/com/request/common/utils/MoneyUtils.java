package com.request.common.utils;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Description: 金额工具类
 * Create DateTime: 2017-11-30 18:40
 *
 * 

 */
public class MoneyUtils {

    /**
     * @param amount 以元为单位的金额
     * @return 以厘为单位的整数
     */
    public static long getCiFromAmout(BigDecimal amount) {
        return amount.multiply(new BigDecimal(1000))
                .setScale(0, RoundingMode.HALF_UP).longValue();
    }

    /**
     * 从以元为单位的金额中获取以分为单位的整数
     *
     * @param amount 以元为单位的金额
     * @return 以分为单位的整数
     */
    public static long getCentFromAmount(BigDecimal amount) {
        return amount.multiply(new BigDecimal(100))
                .setScale(0, RoundingMode.HALF_UP).longValue();
    }

    /**
     * 根据以分为单位的整数生成舍入到小数点后两位的以元为单位的字符串
     *
     * @param cent 以分为单位的整数
     * @return 显示字符串
     */
    public static String getDisplayTextFromCent(long cent) {
        return new BigDecimal(cent).multiply(new BigDecimal(100))
                .setScale(2, RoundingMode.HALF_UP).toPlainString();
    }

    /**
     * 根据以份为单位的整数生成支付宝支付的金额（以元为单位的字符串）
     *
     * @param cent 以分为单位的整数
     * @return 支付宝金额字符串
     */
    public static String getAlipayAmountFromCent(long cent) {
        return new BigDecimal(cent)
                .divide(new BigDecimal(100), 2, RoundingMode.HALF_UP).toString();
    }

    /**
     * 把需要转换的以元为单位的金额转换为以两位小数点结尾的BigDecimal类型的金额
     *
     * @param param double浮点数
     * @return 需要四舍五入的double浮点数
     */
    public static BigDecimal getMoneyAmount(double param) {
        return new BigDecimal(param).setScale(2, RoundingMode.HALF_UP);
    }

}
