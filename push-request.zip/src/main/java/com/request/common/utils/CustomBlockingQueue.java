package com.request.common.utils;

import java.util.concurrent.LinkedBlockingQueue;

/**
 * Description:
 * Create DateTime: 2020/4/28 17:14
 *
 * 

 */
public class CustomBlockingQueue<E> extends LinkedBlockingQueue<E> {

    public CustomBlockingQueue(int capacity) {
        super(capacity);
    }

    @Override
    public boolean offer(E e) {
        try {
            put(e);
            return true;
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
        }
        return false;
    }
}
