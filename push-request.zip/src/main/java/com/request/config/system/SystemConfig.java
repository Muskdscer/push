package com.request.config.system;

import com.request.common.constants.RedisConstant;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * Description:
 * Create DateTime: 2020-04-16 11:07
 *
 * 

 */
@Slf4j
@Component
public class SystemConfig {


    @Resource
    private RedisTemplate<String, String> redisTemplate;

    /**
     * 获取参数值
     *
     * @param name 参数名
     * @return 参数值
     */
    public String getParam(String name) {
        if (StringUtils.isBlank(name)) {
            return null;
        }
        return String.valueOf(redisTemplate.opsForHash().get(RedisConstant.PUSH_ORDER_SYSTEM_PARAM, name.trim()));
    }


}
