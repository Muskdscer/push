package com.kx.push.dao.mapper.platform;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.kx.push.entity.platform.PhoneOrderSuccessProbability;

/**
 * Description:
 * Create DateTime: 2020/4/23 18:02
 *
 *

 */
public interface PhoneOrderSuccessProbabilityMapper extends BaseMapper<PhoneOrderSuccessProbability> {
}
