package com.kx.push.dao.mapper.platform;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.kx.push.entity.platform.SystemParam;

/**
 * Description:
 * Create DateTime: 2020-04-16 11:47
 *
 * 

 */
public interface SystemParamMapper extends BaseMapper<SystemParam> {
}
