package com.kx.push.dao.mapper.platform;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.kx.push.entity.platform.TpPhoneOrderCallBackLog;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 *

 * @since 2020-04-01
 */
public interface TpPhoneOrderCallBackLogMapper extends BaseMapper<TpPhoneOrderCallBackLog> {

}
