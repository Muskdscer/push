package com.kx.push.dao.mapper.platform;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.kx.push.entity.platform.ShopMatchClassify;

/**
 * Description:
 * Create DateTime: 2020/4/20 16:20
 *
 * 

 */
public interface ShopMatchClassifyMapper extends BaseMapper<ShopMatchClassify> {
}
