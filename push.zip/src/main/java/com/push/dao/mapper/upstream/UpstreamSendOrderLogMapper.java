package com.kx.push.dao.mapper.upstream;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.kx.push.entity.upstream.UpstreamSendOrderLog;

/**
 * Description:
 * Create DateTime: 2020/3/31 19:20
 *
 *

 */
public interface UpstreamSendOrderLogMapper extends BaseMapper<UpstreamSendOrderLog> {
}
