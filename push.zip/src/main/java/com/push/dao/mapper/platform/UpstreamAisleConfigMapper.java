package com.kx.push.dao.mapper.platform;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.kx.push.entity.upstream.UpstreamAisleConfig;

/**
 * Description:
 * Create DateTime: 2020/8/18 16:38
 *
 * 

 */
public interface UpstreamAisleConfigMapper extends BaseMapper<UpstreamAisleConfig> {
}
