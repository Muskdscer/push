package com.kx.push.dao.mapper.platform;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.kx.push.entity.platform.PhoneOrderStatistics;

/**
 * Description:
 * Create DateTime: 2020/4/22 16:27
 *
 * 

 */
public interface PhoneOrderStatisticsMapper extends BaseMapper<PhoneOrderStatistics> {
}
