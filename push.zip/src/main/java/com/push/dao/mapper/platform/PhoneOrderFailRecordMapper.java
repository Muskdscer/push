package com.kx.push.dao.mapper.platform;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.kx.push.entity.platform.PhoneOrderFailRecord;

/**
 * Description:
 * Create DateTime: 2020/4/11 19:52
 *
 *

 */
public interface PhoneOrderFailRecordMapper extends BaseMapper<PhoneOrderFailRecord> {
}
