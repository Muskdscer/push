package com.kx.push.dao.mapper.platform;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.kx.push.entity.platform.TpPhoneOrderUpstreamQuery;


/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * 

 * @since 2020-05-12
 */
public interface TpPhoneOrderUpstreamQueryMapper extends BaseMapper<TpPhoneOrderUpstreamQuery> {

}
