package com.kx.push.dao.mapper.platform;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.kx.push.entity.platform.SystemBlackPhone;

public interface SystemBlackPhoneMapper extends BaseMapper<SystemBlackPhone> {

}
