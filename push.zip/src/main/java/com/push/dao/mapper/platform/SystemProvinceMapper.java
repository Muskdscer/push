package com.kx.push.dao.mapper.platform;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.kx.push.entity.platform.SystemProvince;

/**
 * Description:
 * Create DateTime: 2020-04-16 17:15
 *
 * 

 */
public interface SystemProvinceMapper extends BaseMapper<SystemProvince> {
}
