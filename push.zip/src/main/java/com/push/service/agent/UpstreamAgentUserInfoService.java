package com.kx.push.service.agent;

import com.baomidou.mybatisplus.extension.service.IService;
import com.kx.push.entity.agent.UpstreamAgentUserInfo;

/**
 * <p>
 * 渠道代理商用户表 服务类
 * </p>
 *
 *

 * @since 2020-04-26
 */
public interface UpstreamAgentUserInfoService extends IService<UpstreamAgentUserInfo> {

}
