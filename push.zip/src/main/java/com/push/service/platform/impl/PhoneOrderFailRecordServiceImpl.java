package com.kx.push.service.platform.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.kx.push.dao.mapper.platform.PhoneOrderFailRecordMapper;
import com.kx.push.entity.platform.PhoneOrderFailRecord;
import com.kx.push.service.platform.PhoneOrderFailRecordService;
import org.springframework.stereotype.Service;

/**
 * Description:
 * Create DateTime: 2020/4/11 19:50
 *
 * 

 */
@Service
public class PhoneOrderFailRecordServiceImpl extends ServiceImpl<PhoneOrderFailRecordMapper, PhoneOrderFailRecord> implements PhoneOrderFailRecordService {
}
