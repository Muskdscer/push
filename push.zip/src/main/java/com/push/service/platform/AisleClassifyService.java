package com.kx.push.service.platform;


import com.baomidou.mybatisplus.extension.service.IService;
import com.kx.push.entity.platform.AisleClassify;

/**
 * <p>
 * 渠道管道分类表 服务类
 * </p>
 *
 * 

 * @since 2020-06-23
 */
public interface AisleClassifyService extends IService<AisleClassify> {

}
