package com.kx.push.common.webfacade.vo.platform;

import lombok.Data;

/**
 * Description:
 * Create DateTime: 2020/4/26 17:37
 *
 * 

 */
@Data
public class ListUpstreamUserInfoVO {

    private Long id;

    private String upstreamName;
}
