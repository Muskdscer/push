package com.kx.push.common.webfacade.vo.platform;

import lombok.Data;

/**
 * Description:
 * Create DateTime: 2020/3/30 11:43
 *
 *

 */
@Data
public class GetExtractionVO {
    private Object Data;
    private Object Total;
}
