package com.kx.push.common.webfacade.bo.platform;

import com.kx.push.common.webfacade.bo.BaseBO;
import com.kx.push.common.webfacade.error.CommonException;
import com.kx.push.common.webfacade.error.ErrorEnum;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

/**
 * Description:
 * Create DateTime: 2020-03-31 09:59
 *
 *

 */
@Data
public class ModifyShopUserInfoBO extends BaseBO {

    private Long id;

    private String shopName;

    private String password;

    private String appId;

    private String appKey;

    private String phoneNumber;

    private Long matchClassifyId;

    private Double rate;

    private String pushSite;

    private Integer pushNum;

    private String querySite;

    private String whiteIp;
    //警告阀值
    private Long alarmNumber;

    /**
     * 账号状态
     */
    private Integer status;

    @Override
    public void validate() {
        super.validate();
        if (StringUtils.isBlank(phoneNumber)
                || StringUtils.isBlank(shopName)
                || rate == null) {
            throw new CommonException(ErrorEnum.REQUIRED_PARAM_EMPTY);
        }
    }

}
