package com.kx.push.common.constants;

import lombok.Data;

/**
 * Description:
 * Create DateTime: 2020/3/27 18:53
 *
 *

 */
@Data
public class DeleteFlagConstant {
    public static final Integer UNDELETE = 0;//逻辑未删除
    public static final Integer DELETE = 1;//逻辑删除

}
