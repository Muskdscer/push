package com.kx.push.common.constants;

/**
 * Description: Redis常量
 * Create DateTime: 2020-03-24 13:54
 *
 *

 */
public interface SessionConstant {

    String LOGIN_USER_INFO = "loginUserInfo";

}
